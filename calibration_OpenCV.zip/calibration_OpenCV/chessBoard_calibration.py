import numpy as np
import cv2 as cv
import glob

import config

# termination cirteria
criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)

objp = np.zeros((config.BOARD[0] * config.BOARD[1], 3), dtype = np.float32)
objp[:, :2] = np.mgrid[0:config.BOARD[0], 0:config.BOARD[1]].T.reshape(-1, 2)
# mgrid -> [00][10][20][01][11][21][20][21][22]

objPoints = [] # 3d points in real world space
imgPoints = [] # 2d points in image plane

import os
current = os.getcwd()
print(current)
glob_images = glob.glob(current + '/images/*.png')
print(len(glob_images))
SIZE = None
for glob_img in glob_images:
    image = cv.imread(glob_img)
    image_gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
    if not SIZE:
        SIZE = image_gray.shape[:2]

    ret, corners = cv.findChessboardCorners(image_gray, config.BOARD, None)
    if ret == True:
        objPoints.append(objp)
        corners_second = cv.cornerSubPix(image_gray, corners, (11, 11), (-1, -1), criteria)

        imgPoints.append(corners)

        cv.drawChessboardCorners(image, config.BOARD, corners_second, ret)
        # cv.imshow('Corner points on the chessBoard.', image)
        # cv.waitKey(500)


cv.destroyAllWindows()

###### Calibrating ######
ret, camMatrix_org, distortion, rotater, translater = cv.calibrateCamera(objPoints, imgPoints, config.CAMERA_SIZE, None, None)
print(camMatrix_org)
print(rotater[0])
print(translater[0])
np.savez("CamParams", camMatrix_org = camMatrix_org, distortion = distortion, rotater = rotater, translater = translater)

###### Undistorted Image ######
for glob_img in glob_images:
    image = cv.imread(glob_img)
    image_gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    # undistorting image #
    camMatrix_undistorted, roi = cv.getOptimalNewCameraMatrix(camMatrix_org, distortion, SIZE, 1, SIZE)
    image_undistorted = cv.undistort(image, camMatrix_org, distortion, None, camMatrix_undistorted)
    # x, y, w, h = roi
    # image_undistorted = image_undistorted[y:y+h, x:x+w]
    
    # cv.imshow('Corner points on the chessBoard.', image_undistorted)
    # cv.waitKey(500)    

    ###### Undistort with remapping ######
    mapX, mapY = cv.initUndistortRectifyMap(camMatrix_org, distortion, None, camMatrix_undistorted, SIZE, 5)
    image_remapped = cv.remap(image, mapX, mapY, cv.INTER_LINEAR)

    ###### ROI of the image ######
    x, y, w, h = roi
    image_remapped = image_remapped[y:y+h, x:x+w]
    # cv.imwrite('ROIofRemappedUndistortedImage.png', image_remapped)

    ###### mean error of reprojection error ? #######
    mean_error = 0

    for i in range(len(objPoints)):
        imgPoints_second, _ = cv.projectPoints(objPoints[i], rotater[i], translater[i], camMatrix_org, distortion)
        error_single = cv.norm(imgPoints[i], imgPoints_second, cv.NORM_L2) / len(imgPoints_second)
        mean_error += error_single
    print(mean_error)