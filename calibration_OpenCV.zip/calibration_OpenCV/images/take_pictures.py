import cv2 as cv
import time

cam = cv.VideoCapture(0)
cam.release()
cam = cv.VideoCapture(0)
cv.namedWindow("test")

EVERY_SECONDS = 6

img_counter = 0
second = 0
while True:
    int_time = int(time.time())+1
    ret, frame = cam.read()
    if not ret:
        print("failed to grab frame")
        break
    cv.imshow("test", frame)

    k = cv.waitKey(1)
    if k%256 == 27:
        # ESC pressed
        print("Escape hit, closing...")
        break
    if k%256 == 32 or int_time % EVERY_SECONDS == 0 and int_time != second:
        second = int_time
        # SPACE pressed
        img_name = "opencv_frame_{}.png".format(img_counter)
        cv.imwrite(img_name, frame)
        print("{} written!".format(img_name))
        img_counter += 1

cam.release()

cv.destroyAllWindows()