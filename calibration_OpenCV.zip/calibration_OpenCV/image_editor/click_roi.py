import cv2 as cv

class BoundingBoxWidget(object):
    def __init__(self):
        
        # image management system ?

        self.image_org = cv.imread('/home/fuxi/Pictures/ww.jpeg')
        self.clone = self.image_org.copy()

        cv.namedWindow('Image Window')
        cv.setMouseCallback('Image Window', self.extract_coordinates)

        self.rectangle_coor = []

    def extract_coordinates(self, event, x, y, flags, parameters):
        if event == cv.EVENT_LBUTTONDOWN:
            self.rectangle_coor = [(x, y)]

        elif event == cv.EVENT_LBUTTONUP:
            self.rectangle_coor.append((x, y))

            cv.rectangle(self.clone, self.rectangle_coor[0], self.rectangle_coor[1], (50, 200, 50))
            cv.imshow('Image Window', self.clone)

        elif event == cv.EVENT_RBUTTONDOWN:
            self.clone = self.image_org.copy()

    def return_clone(self):
        return self.clone

if __name__ == '__main__':
    real_bb_widget = BoundingBoxWidget()

    while True:
        cv.imshow('Image Window', real_bb_widget.return_clone())
        
        key = cv.waitKey(1)
        if key == ord('q'):
            cv.destroyAllWindows()
            exit(1)
