import cv2 as cv
import numpy as np

def draw_arrow(image, corners, points):
    corner = tuple(int(x) for x in corners[0].ravel())
    print(tuple(int(x) for x in points[0].ravel()))
    cv.line(image, corner, tuple(int(x) for x in points[0].ravel()), (255, 0, 0), 8)
    cv.line(image, corner, tuple(int(x) for x in points[1].ravel()), (0, 255, 0), 8)
    cv.line(image, corner, tuple(int(x) for x in points[2].ravel()), (0, 0, 255), 8)

def draw_box(image, corners, points):
    points = np.int32(points).reshape(-1, 2)

    # draw ground floor in color
    image = cv.drawContours(image, [points[:4]], -1, (0, 255, 0), 3)

    # draw pillars in color
    for i, j in zip(range(4), range(4, 8)):
        cv.line(image, tuple(points[i]), tuple(points[j]), (255, 0, 0), 3)
    
    # draw top layer in color
    cv.drawContours(image, [points[4:]], -1, (0, 0, 255), 3)


# ret, camMatrix_org, distortion, rvecs, tvecs = cv.calibrateCamera(objPoints, imgPoints, frameSize, None, None)


# camMatrix_undistorted, roi = cv.getOptimalNewCameraMatrix(camMatrix_org, distortion, frame.shape[:2])


# undistort = cv.undistort(image, camMatrix_org, distortion, None, camMatrix_undistorted)


# mapX, mapY = cv.initUndistortRectifyMap(camMatrix_org, distrotion, None, camMatrix_undistorted)


# image_remap = cv.remap(image, mapX, mapY, cv.INTER_LINEAR)