from pickle import NONE
import numpy as np
import cv2 as cv
import glob

import config
import methods
import chessBoard_calibration

with np.load('CamParams.npz') as file:
    camMatrix, distortion, rotater, translater = [file[i] for i in ('camMatrix_org', 'distortion', 'rotater', 'translater')]

criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)
axis = np.float32([[3, 0, 0], [0, 3, 0], [0, 0, -3]]).reshape(-1, 3)
axisBoxes = np.float32([[0,0,0],[0,3,0],[3,3,0],[3,0,0],
[0,0,-3],[0,3,-3],[3,3,-3],[3,0,-3]])

import os
current = os.getcwd()
print(current)
glob_images = glob.glob(current + '/images/*.png')
print(len(glob_images))
for image_glob in glob_images:
    image = cv.imread(image_glob)
    image_gray = cv.cvtColor(image, cv. COLOR_BGR2GRAY)
    ret, corners = cv.findChessboardCorners(image_gray, config.BOARD, None)

    if ret == True:
        corners_second = cv.cornerSubPix(image_gray, corners, (11, 11), (-1, -1), criteria)
        # Find the rotation and translation.
        ret, rotater, translater = cv.solvePnP(chessBoard_calibration.objp, corners_second, camMatrix, distortion)
        # Project 3D points to image plane
        points, project = cv.projectPoints(axis, rotater, translater, camMatrix, distortion)
        methods.draw_arrow(image, corners_second, points)
        cv.imshow('Vectorial Maxtrix Image', image)
        if cv.waitKey(0) & 0XFF == ord('s'):
            cv.imwrite('pose' + image_glob, image)
        points, project = cv.projectPoints(axisBoxes, rotater, translater, camMatrix, distortion)
        methods.draw_box(image, corners_second, points)
        cv.imshow('Vectorial Maxtrix Image', image)
        if cv.waitKey(0) & 0XFF == ord('s'):
            cv.imwrite('pose' + image_glob, image)

cv.destroyAllWindows()