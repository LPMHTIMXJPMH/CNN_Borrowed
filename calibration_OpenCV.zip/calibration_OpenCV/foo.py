import numpy as np

BOARD = (9, 6)

print(np.mgrid[0:BOARD[0], 0:BOARD[1]].T.reshape(-1, 2))